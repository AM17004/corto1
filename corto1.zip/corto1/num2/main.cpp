#include <iostream>

int main() {
    int i, pos;
    int n, brrd;

    printf("Indique el tamaño del vector: ");
    scanf("%i",&n);

    int vector[n];


    for(i=0;i<n;i++){
        printf("Valor de la posicion %i: ",i+1);
        scanf("%i",&vector[i]);
    }
    printf("\nVector actual:\n");

    for(i=0;i<n;i++){
        printf("Elemento [%i] Posicion %i = %i\n",i,i+1,vector[i]);
    }


    printf("\n¿Que posicion desea eliminar?: ");
    scanf("%i",&pos);

    if(pos>n){
        printf("El valor colocado es mayor que el tamaño del vector.-------");
    }
    else{
        brrd = vector[pos-1];
        for(i=0;i<n;i++){
            if(i==(pos-1)){
                while(i<n){
                    vector[i] = vector[i+1];
                    i++;
                }
                break;
            }
        }

        printf("\nVector actual :\n");
        n-=1;
        for(i=0;i<n;i++){
            printf("Elemento [%i] Posicion %i = %i\n",i,i+1,vector[i]);
        }

        printf("\nNumero eliminado: %i",brrd); // Muestra el numero eliminado.
    }
    return 0;
}